import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;
import java.util.Scanner;
import java.io.*;

public class TestJUnit {

   /*@Test
   public void testInput() {
       String data = "1234567812345678";
       InputStream stdin = System.in;
       System.setIn(new ByteArrayInputStream(data.getBytes()));
       Example ex = new Example();
       assertEquals(ex.Validate(),data);
       System.setIn(stdin);
   }*/
   @Test
    public void testInput1() {
       String data = "3125145643589796";
       System.setIn(new ByteArrayInputStream(data.getBytes()));
       assertEquals("Valid Card",Assignment2.Validate());
   }
   @Test
    public void testInput2() {
       String data = "3125145643589795";
       System.setIn(new ByteArrayInputStream(data.getBytes()));
       assertEquals("Invalid Card",Assignment2.Validate());
   }
   @Test
   public void testInput3() {
       String data = "000000000000000";
       System.setIn(new ByteArrayInputStream(data.getBytes()));
       assertEquals("Invalid Card",Assignment2.Validate());
   }



}
